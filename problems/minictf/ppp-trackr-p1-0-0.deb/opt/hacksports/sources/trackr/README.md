# Trackr

## Purpose

TBD

## Notes

* TBD

## Guidance

* TBD

## Solution

TBD

## Flag

`CTF{why_is_it_xss_but_not_xsrf}`
